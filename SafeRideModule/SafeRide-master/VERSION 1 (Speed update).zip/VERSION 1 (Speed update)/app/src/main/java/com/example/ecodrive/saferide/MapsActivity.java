package com.example.ecodrive.saferide;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ecodrive.saferide.Services.AccelerationDetectionService;
import com.example.ecodrive.saferide.Services.ActivityRecognitionService;
import com.example.ecodrive.saferide.Services.DetectedActivityService;
import com.example.ecodrive.saferide.Services.MapService;
import com.google.android.gms.location.DetectedActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.RoundCap;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import android.os.Vibrator;

import androidx.fragment.app.FragmentActivity;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    final private int REQUEST_COURSE_ACCESS = 123;
    boolean permissionGranted = false;
    private float live_speed;
    private float live_acceleration;
    private double live_distance;
    private double Co2emission = 0;
    private String fuelType = "petrol";
    BroadcastReceiver broadcastReceiverForRecognition;
    BroadcastReceiver broadcastReceiverForAcceleration;
    private int[] activitiesConfidence;
    boolean firstTime;
    private Marker previousMarker = null;
    private static final String TAG = MapsActivity.class.getName();
    private LatLng currentLatLng;
    private float accuracy;
    private static int latLngCount=0;
    TextView activtyUpdates;
    TextView accelUpdates;
    private List<LatLng> onWayPoints;
    TextView speedDisplay;
    private DecimalFormat decimalFormatForSpeed;
    private DecimalFormat decimalFormatForDistance;
    private FusedLocationProviderClient mfusedlocationclient;
    private LatLng previousLatLng;
    private double x,y,z,mAccelCurrent,mAccelLast = 0,mAccel;
    private Vibrator vibrateObj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        activtyUpdates = findViewById(R.id.activtyInfo);
        accelUpdates = findViewById(R.id.accel);
        activitiesConfidence = new int[5];
        onWayPoints=new ArrayList<>();
        speedDisplay = findViewById(R.id.speed);
        decimalFormatForSpeed = new DecimalFormat("0.00##");
        decimalFormatForDistance = new DecimalFormat("0.0000##");
        mfusedlocationclient = LocationServices.getFusedLocationProviderClient(this);
        vibrateObj = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 123);
        }

        //ActivityRecognitionReceiver
        broadcastReceiverForRecognition = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(DetectedActivityService.RECOGNITION_SERVICE_BROADCAST)) {
                    int type = intent.getIntExtra("type", -1);
                    int confidence = intent.getIntExtra("confidence", 0);
                    handleUserActivity(type, confidence);
                }
            }
        };
        LocalBroadcastManager.getInstance(this).registerReceiver((broadcastReceiverForRecognition),
                new IntentFilter(DetectedActivityService.RECOGNITION_SERVICE_BROADCAST)
        );

        //AccelerationReceiver
        broadcastReceiverForAcceleration = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                x = intent.getDoubleExtra("AXIS-X",0);
                y = intent.getDoubleExtra("AXIS-Y",0);
                z = intent.getDoubleExtra("AXIS-Z",0);
                //Log.d(TAG,"INSIDE ACCELERATION BROADCAST RECEIVER");

                mAccelCurrent = Math.sqrt(x * x + y * y + z * z);
                double delta = mAccelCurrent - mAccelLast;
                mAccel = mAccel * 0.9f + delta;
                double g = (mAccelCurrent / 9.81);
                //if(mAccel > 50){
                if(g > 6){
                //Log.d("Change in acceleration", String.valueOf(mAccel));
                Log.d("Change in acceleration", String.valueOf(g));
                vibrateObj.vibrate(1000);
                //Toast.makeText(getBaseContext(),"Movement detected",Toast.LENGTH_SHORT).show();
                }
                accelUpdates.setText("X: "+x+"\nY: "+y+"\nZ: "+z+"\nG: "+g);
            }
        };
        LocalBroadcastManager.getInstance(this).registerReceiver((broadcastReceiverForAcceleration),
                new IntentFilter(AccelerationDetectionService.ACCELERATION_SERVICE_BROADCAST)
        );

        startTrackingActivities();



    }

    private void startTrackingActivities() {
        Intent intent = new Intent(MapsActivity.this, ActivityRecognitionService.class);
        startService(intent);
    }

    public void startAccelerationService(View view) {
        Intent intent = new Intent(MapsActivity.this, AccelerationDetectionService.class);
        startService(intent);
    }

    private void handleUserActivity(int type, int confidence) {

        String activityName = "";
        switch (type) {
            case DetectedActivity.IN_VEHICLE:
                activityName = "IN_VEHICLE";
                Log.d(TAG, "In Vehicle");
                //activtyUpdates.setText("Driving  Confidence: " + confidence);
                activitiesConfidence[0] = confidence;
                break;

            case DetectedActivity.ON_BICYCLE:
                activityName = "ON_BICYCLE";
                Log.d(TAG, "On Bicycle");
                activitiesConfidence[1] = confidence;
                break;

            case DetectedActivity.WALKING:
                activityName = "WALKING";
                Log.d(TAG, "Walking");
                activitiesConfidence[2] = confidence;
                break;

            case DetectedActivity.RUNNING:
                activityName = "RUNNING";
                Log.d(TAG, "Running");
                activitiesConfidence[3] = confidence;
                break;

            case DetectedActivity.STILL:
                activityName = "STILL";
                Log.d(TAG, "Still");
                activitiesConfidence[4] = confidence;
                break;
        }
        int activty[] = getMax(activitiesConfidence);

        /*if (confidence > 75) {
            Toast.makeText(getBaseContext(), "Are you " + activityName + " ?\nConfidence: " + confidence, Toast.LENGTH_SHORT).show();
        }*/
        updateTextView(Constants.ACTIVITY_NAMES[activty[1]]);

    }

    int[] getMax(int[] activitiesConfidence)
    {
        int activity[]={0,0};
        for(int i=0;i<activitiesConfidence.length;i++)
            if(activity[0]<activitiesConfidence[i]) {
                activity[0] = activitiesConfidence[i];
                activity[1]=i;
            }
        return activity;
    }

    void updateTextView(String activityName) {
        StringBuilder sb = new StringBuilder();
        sb.append("IN_VEHICLE: " + activitiesConfidence[0] + "\t ");
        sb.append("ON_BICYCLE: " + activitiesConfidence[1] + "\n");
        sb.append("WALKING: " + activitiesConfidence[2] + "\t ");
        sb.append("RUNNING: " + activitiesConfidence[3] + "\n");
        sb.append("STILL: " + activitiesConfidence[4] + "\n");
        sb.append("You Are " + activityName);
        activtyUpdates.setText(sb);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        Log.d(TAG, "OnMapREADY Detected");
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            android.Manifest.permission.ACCESS_COARSE_LOCATION},
                    REQUEST_COURSE_ACCESS);
            return;
        } else {
            permissionGranted = true;
        }
        if (permissionGranted) {
            moveToUserLocation();
            mMap.setMyLocationEnabled(true);
            mMap.setTrafficEnabled(false);
            startLocationTracking();
        }
        //Location Update Receiver
        BroadcastReceiver receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                live_speed = intent.getFloatExtra("SPEED", 0);
                live_acceleration = intent.getFloatExtra("ACCELERATION", 0);
                live_distance = intent.getDoubleExtra("DISTANCE", 0);
                accuracy = intent.getFloatExtra("ACCURACY",0);
                currentLatLng=intent.getExtras().getParcelable("CURRENT_LATLNG");
                previousLatLng=intent.getExtras().getParcelable("PREVIOUS_LATLNG");

                if(latLngCount%2==0){
                    onWayPoints.add(currentLatLng);
                }
                latLngCount+=1;
                if(previousMarker!=null)
                    previousMarker.remove();

                MarkerOptions markerOptions = new MarkerOptions().position(currentLatLng);
                markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE));
                previousMarker = mMap.addMarker(markerOptions);

                Polyline livePolyline = mMap.addPolyline(new PolylineOptions().addAll(onWayPoints));
                livePolyline.setColor(ContextCompat.getColor(getBaseContext(), R.color.Blue));
                livePolyline.setEndCap(new RoundCap());livePolyline.setEndCap(new RoundCap());
                livePolyline.setWidth(10);
                livePolyline.setClickable(true);

                updateLocationTextView(live_acceleration, live_speed, live_distance, accuracy);


                Log.d(TAG, "ONRECEIVE MAP ACTIVITY");
                Log.d(TAG, "ONWAYPOINTS SIZE: "+onWayPoints.size());
            }
        };
        LocalBroadcastManager.getInstance(this).registerReceiver((receiver),
                new IntentFilter(MapService.MAP_SERVICE_BROADCAST)
        );
    }

    void startLocationTracking()
    {
        Intent serviceIntent = new Intent(this, MapService.class);
        serviceIntent.putExtra("PERMISSION_STATUS", permissionGranted);
        startService(serviceIntent);
    }

    void moveToUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mfusedlocationclient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
            @Override
            public void onComplete(@NonNull Task<Location> task) {
                Location location = task.getResult();
                if(location!=null) {
                    Log.d(TAG,"INSIDE FUSED: "+ "" + location.getLatitude() + " " + location.getLongitude());
                    Log.d(TAG,"BEARING : "+ "" + location.getBearing());
                    Log.d(TAG,"ACCURACY : "+ "" + location.getAccuracy());
                    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()),16));
                    Toast.makeText(getBaseContext(), "Your Location: \nlat:" + location.getLatitude() + " Lng:" + location.getLongitude(), Toast.LENGTH_SHORT).show();
                    //mMap.animateCamera(CameraUpdateFactory.zoomTo(16));
                }
            }
        });
    }
    void updateLocationTextView(float live_acceleration, float live_speed, double live_distance, float accuracy){

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Acceleration: " + decimalFormatForSpeed.format(live_acceleration) +
                "\nSpeed: " + decimalFormatForSpeed.format(live_speed) + " km/hr" + "" +
                "\nDistance: " + decimalFormatForDistance.format(live_distance) + " m");
        //+"\nAccuracy : "+accuracy);

        speedDisplay.setText(stringBuilder);

    }


}
