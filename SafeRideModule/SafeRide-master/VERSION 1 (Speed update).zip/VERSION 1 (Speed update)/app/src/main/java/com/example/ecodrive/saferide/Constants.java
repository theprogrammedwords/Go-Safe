package com.example.ecodrive.saferide;

public class Constants {
    public static final String[] ACTIVITY_NAMES = {"IN_VEHICLE","ON_BICYCLE","WALKING","RUNNING","STILL"};
}
