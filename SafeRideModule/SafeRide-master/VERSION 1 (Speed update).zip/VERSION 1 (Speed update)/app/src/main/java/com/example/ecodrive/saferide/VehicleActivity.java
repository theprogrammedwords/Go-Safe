package com.example.ecodrive.saferide;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.util.HashMap;

public class VehicleActivity extends AppCompatActivity {

    private static final String TAG = "VehicleActivity";
    EditText _vNumber;
    Button _submitButton;
    EditText _vnameText;
    TextView _addVehicle;
    RadioButton _twoWheel;
    RadioButton _fourWheel;
    private FirebaseFirestore firestore;
    private CollectionReference collectionReference;
    private DocumentReference documentReference;
    private HashMap<String,String> hashMap;

    private FirebaseUser user;
    private FirebaseAuth firebaseAuth;
    private String vname,vnumber,twheel,fwheel;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle);
        firestore = FirebaseFirestore.getInstance();
        _twoWheel=(RadioButton) findViewById(R.id.twoWheel);
        _fourWheel=(RadioButton) findViewById(R.id.fourWheel);
        _vNumber = (EditText) findViewById(R.id.input_vnumber);

        _submitButton = (Button) findViewById(R.id.btn_submit);

        _vnameText = (EditText) findViewById(R.id.input_name);
        _addVehicle=(TextView) findViewById(R.id.link_addVehicle);
        firebaseAuth=FirebaseAuth.getInstance();
        hashMap = new HashMap<>();
        firestore = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();

        _submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                signup();



            }
        });
        _addVehicle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(VehicleActivity.this, VehicleActivity.class);
                startActivity(intent);

            }
        });



    }



    public void signup() {
        Log.d(TAG, "SignUp");

        vname = _vnameText.getText().toString();
        vnumber = _vNumber.getText().toString();
        twheel = _twoWheel.getText().toString();
        fwheel = _fourWheel.getText().toString();

        if (vname.equals("") && vnumber.equals("") ) {
            Toast.makeText(this, "One or more fields are empty", Toast.LENGTH_LONG).show();
        }
        else {
            documentReference = firestore.collection("USER LIST").document(user.getUid()).collection("VEHICLE LIST").document(vnumber);
            hashMap.put("Registration Number", vnumber);
            hashMap.put("Vehicle Name", vname);
            hashMap.put("Vehicle Type",twheel);
            hashMap.put("Vehicle Type",fwheel);
            documentReference.set(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    Log.d("Vehicle details", "Data added to databse");
                }
            });
        }



    }
}
